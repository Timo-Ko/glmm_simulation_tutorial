This repository contains all materials (reproducible manuscript, including R code and all simulation results) for the manuscript titled:

**A Tutorial on Tailored Simulation-Based Sample Size Planning for Experimental Designs with Generalized Linear Mixed Models**


